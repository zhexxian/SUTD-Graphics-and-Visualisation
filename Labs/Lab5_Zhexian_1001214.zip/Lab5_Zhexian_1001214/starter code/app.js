/**
 * Initialize WebGLRenderer and attach it to the html body
 */
var renderer = new THREE.WebGLRenderer();
renderer.setClearColor(0xffffff, 1);
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

var scene = new THREE.Scene();

// fov, aspect ratio, near plane, far plane
var camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
/**
 * Hierarchy object to attach camera on, so later we can perform rotation on different axis
 * without affecting the rotation matrix of one and another.
 */
var yawObject = new THREE.Object3D(); // rotation on y-axis
var pitchObject = new THREE.Object3D(); // rotation on x-axis
pitchObject.add(camera);
yawObject.add(pitchObject);
yawObject.position.z = 5;
yawObject.position.y = 1.5;
scene.add(yawObject);


// when window resize, we need to update the rendering canvas size and camera aspect ratio
// so the rendered view is not distorted.
window.onresize = function() {
	renderer.setSize(window.innerWidth, window.innerHeight);
	camera.aspect = window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();
}

// create base plane
var geom = new THREE.PlaneGeometry(40, 120);
var mat = new THREE.MeshBasicMaterial({
	color: 0xcdcdcd
});
var plane = new THREE.Mesh(geom, mat);
plane.rotateX(-Math.PI / 2);
scene.add(plane);


//////////////////////////////////// # 2 ////////////////////////////////////
// @todo: replace this block and populate the scene with random number of
// objects at random places
var box = new THREE.BoxGeometry(1, 1, 1);
var material = new THREE.MeshBasicMaterial({
	color: 0xff0000
});
var cube = new THREE.Mesh(box, material);
cube.position.set( 0, 1, 0 );
scene.add(cube);
var cubes = [];
for(i=0; i<20*Math.random(); i++){
	cubes[i] = new THREE.Mesh(box, material);
	cubes[i].position.x = 5*Math.random();
	cubes[i].position.y = 5*Math.random();
	cubes[i].position.z = 5*Math.random();
	scene.add(cubes[i]);
}
//////////////////////////////////// end ////////////////////////////////////



//////////////////////////////////// # 3 ////////////////////////////////////
document.addEventListener('mousemove', onMouseMove);

var prevX, prevY = null;
var mouseX, mouseY = 0;
var mouseSensitivity = 0.002;
function onMouseMove(event) {
	mouseX = event.clientX;
	mouseY = event.clientY;
	var movementX = mouseX - (prevX || mouseX);
	var movementY = mouseY - (prevY || mouseY);

	/**
	 * @todo - use the delta between current mouse position
	 * and previous mouse position to alter the viewing angle value.
	 */
	yawObject.rotation.y -= movementX * mouseSensitivity;
	pitchObject.rotation.x -= movementY * mouseSensitivity;

	prevX = mouseX;
	prevY = mouseY;
}
//////////////////////////////////// end ////////////////////////////////////



//////////////////////////////////// # 4 ////////////////////////////////////
document.addEventListener('keyup', onKeyUp);
document.addEventListener('keydown', onKeyDown);

// movement state
var moveForward, moveBackward, moveLeft, moveRight = false;

function onKeyUp(event) {
	console.log("onKeyUp", event.keyCode);
	switch (event.keyCode) {
		case 38: // up
		case 87: // w
			// @todo: alter the key state
			moveForward = false;
			break;

		case 37: // left
		case 65: // a
			// @todo: alter the key state
			moveLeft = false;
			break;

		case 40: // down
		case 83: // s
			// @todo: alter the key state
			moveBackward = false;
			break;

		case 39: // right
		case 68: // d
			// @todo: alter the key state
			moveRight = false;
			break;
	}
}

function onKeyDown(event) {
	console.log("onKeyDown", event.keyCode);
	// the keycode of the key pressed
	switch (event.keyCode) {

		case 38: // up
		case 87: // w
			// @todo: alter the key state
			// when forward key is pressed
			moveForward = true;
			break;

		case 37: // left
		case 65: // a
			// @todo: alter the key state
			moveLeft = true;
			break;

		case 40: // down
		case 83: // s
			// @todo: alter the key state
			moveBackward = true;
			break;

		case 39: // right
		case 68: // d
			// @todo: alter the key state
			moveRight = true;
			break;
	}
}


var movementSpeed = 0.125;

function movementUpdate(delta) {
	delta = delta * movementSpeed;
	/**
	 * @todo - update the position of the camera according to
	 * user key state and delta
	 */
	// when forward or backward key is pressed, translate along Z-axis with given value
	if(moveForward){
		yawObject.translateZ( movementSpeed );
	}
	else if(moveBackward) {
		yawObject.translateZ( -movementSpeed );
	}
	// when left or right key is pressed, translate along X-axis with given value
	else if(moveLeft) {
		yawObject.translateX( movementSpeed );
	}
	else if(moveRight) {
		yawObject.translateX( -movementSpeed );
	}
	

}
//////////////////////////////////// end ////////////////////////////////////



// render loop

var prev = performance.now();
var now = performance.now();

function render() {
	requestAnimationFrame(render);
	renderer.render(scene, camera);
	now = performance.now();
	movementUpdate(now - prev);
	prev = performance.now();
}
render();